﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperMarketSimulation
{
    class PoissonDistribution
    {
        private double lambda;


        public double Lambda
        {
            get { return lambda; }
            set { lambda = value; }
        }

    }
}
